require(graphics)
require(Matrix)

pdf(file="exp6a.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)

data = read.table("../result/exp6a.dat", sep="\t")
lab = data[,1]
data = t(as.matrix(data[2:4]))
data = data * 3
data[2,] = data[1,] - data[2,] 
data[3,] = data[1,] - data[3,] 
lab
plot_colors <- c("cornflowerblue","black", "orange")

barplot( data, 
         space = c(0, 0.3),
         xlab = "", 
         ylab = "",
         col=plot_colors,
         ylim = c(0,14000),
         axes = FALSE, 
         args.legend = list(x="topright", bty="n", ncol=3, cex=1, x.intersp=0.5),
         legend.text = c("FP", "MP", "SMP"),
         beside = TRUE,
 				 names = c("EEG", "Titanic", "Movie", "Housing"),
        cex.names=0.9,
        line=-0.5

)

axis(2, las=1, at=c(0, 1000,2000,3000,4000,5000,6000,7000, 8000, 9000, 10000), labels=paste0(c(0, 1,2,3,4,5,6,7, 8, 9, 10), "K"), cex=0.75) 
mtext(2,text="#Enumerated Pipelines",line=2.7) 
#axis(1, las=1, at=c("1.5","3.5","5.5","8","10"), c("BabyProduct", "EEG", "Puma", "titanic", "Wine")) 
# mtext(1,labels=c("EEG", "Puma", "Titanic", "Wine", "Movie"),line=2) 


box()	              # box around plot       
dev.off() 
