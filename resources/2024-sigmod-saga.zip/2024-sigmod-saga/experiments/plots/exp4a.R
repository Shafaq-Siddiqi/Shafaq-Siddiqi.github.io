require(graphics)
require(Matrix)

pdf(file="exp4a.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)

datasets = c("EEG", "Puma", "Titanic", "Wine", "Movie")
plot_colors <- c("orangered", "black", "cornflowerblue","blue")

data1 = read.table("../result/exp4/EEG_acc.dat", sep="\t")[,2]
print("data 1")
data1
# data2 = read.table("../result/exp4/puma_acc.dat", sep="\t")[,2]
data3 = read.table("../result/exp4/titanic_acc.dat", sep="\t")[,2]
# data4 = read.table("../result/exp4/wine_acc.dat", sep="\t")[,2]
data5 = read.table("../result/exp4/movie_acc.dat", sep="\t")[,2]
# data6 = read.table("../result/exp4/cancer_acc.dat", sep="\t")[,2]
data7 = read.table("../result/exp4/housing_acc.dat", sep="\t")[,2]

data = cbind(as.matrix(data1),as.matrix(data3),as.matrix(data5),as.matrix(data7))
data[,1:3] = data[,1:3]/100
data
points = c(0, 10, 20, 30, 40, 50)
zeroAcc = t(as.matrix(c("0.61", "0.79", "0.76", "0.64")))
zeroAcc
data = rbind(zeroAcc, data)
print(data)
print("---------------")
print("---------------")
print(data[, 1])
print(data[, 2])

plot(points, data[,1],     
        type="o",           
        pch=13, 
        cex=1.1,
        col=plot_colors[1],              
        ylim = c(0.61, 0.85),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        lwd=1.1, 
        lty=1 )


axis(2, las=1, at=c(0.61, 0.64, 0.67, 0.70, 0.73, 0.76, 0.79, 0.82, 0.85), labels=c(0.61, 0.64, 0.67, 0.70, 0.73, 0.76, 0.79, 0.82, 0.85)) # horizontal y axis
axis(1, las=1, at=points, cex.axis=1, line=0)      # horizontal x axis 
mtext(2, text="Accuracy", line=2.7) 
mtext(1, text="# resources", line=2) 


lines(points, data[,2], type="o", pch=15, lty=1, lwd=1.1, col=plot_colors[2], bg=plot_colors[2], cex=1.0)
lines(points, data[,3], type="o", pch=17, lty=1, lwd=1.1, col=plot_colors[3], bg=plot_colors[3], cex=1.0)
lines(points, data[,4], type="o", pch=19, lty=1, lwd=1.1, col=plot_colors[4], bg=plot_colors[4], cex=1.0)
# lines(points, data[,5], type="o", pch=25, lty=1, lwd=1.1, col=plot_colors[5], bg=plot_colors[5], cex=1.0)
# lines(points, data[,6], type="o", pch=4, lty=1, lwd=1.1, col=plot_colors[6], bg=plot_colors[6], cex=1.0)
# lines(points, data[,7], type="o", pch=8, lty=1, lwd=1.1, col=plot_colors[7], bg=plot_colors[7], cex=1.0)

box()	

legend(12, 0.78,
       c("EEG", "Titanic", "Movie", "Housing"), col=plot_colors[c(1,2,3,4,5,6,7)], 
       pch=c(13,15,17,19), lty=c(1), lwd=c(1.1), bty="n", ncol=2, cex=0.85, pt.bg=plot_colors[c(1,2,3,4)]);



dev.off() 
