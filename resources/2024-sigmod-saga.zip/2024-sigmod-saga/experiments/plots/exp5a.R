require(graphics)
require(Matrix)

pdf(file="exp5a.pdf",
  width=5, height=4.0, family="serif", pointsize=14)

points = as.vector(seq(1,5));
input = as.matrix(read.table("../result/exp5a.dat", sep="\t")[2])
input = input[1:5]
# data = rowMeans(matrix(input,7,2))/1000000
data = input/1000000
data
data2 = data[1] * points
plot_colors <- c("orange","black")

plot(   points, data,     
        type="o",           
        pch=25, 
        cex=1.1,
        col=plot_colors[1],              
        ylim = c(0,60),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        log="",
	      lwd=1.1, 
	      lty=1
  )


axis(2, las=2, at = c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60), labels = paste0(c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50, 55, 60), "K"))# horizontal y axis
axis(1, las=1)      # horizontal x axis
mtext(2, text="Execution Time [s]",line=3) 
mtext(1, text="Row Replication Factor (x 14980)",line=2) 

lines(points, data2, type="l", lty=2, lwd=1.1, col=plot_colors[2], cex=1.0)

#segments(16,0,16,570, lty=2, lwd=1.1)
text(9,900,"scale-up")

box()	

legend( "topleft",
       c("EEG","Ideal Scaling"), col=plot_colors, pt.bg=plot_colors,
       pch=c(25,NA), lty=c(1,2), lwd=c(1.1), bty="n");

dev.off() 
