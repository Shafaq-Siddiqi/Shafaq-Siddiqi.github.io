require(graphics)
require(Matrix)

pdf(file="exp6b.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)

data = read.table("../result/exp6b.dat", sep=",", header=FALSE);
lab = data[,1]
data = t(as.matrix(data[2]))
data = data/60

lab
plot_colors <- c( "orangered", "orange",  "blue",  "cornflowerblue", "gray40", "black" )

barplot( data, 
         space = c(0.2,0.2),
         xlab = "", 
         ylab = "",
         col=plot_colors,
         ylim = c(0,9000),
         axes = FALSE, 
         args.legend = list(x="topright", c("NP","OP", "FP", "Flat", "FP-R", "Flat-R"), bty="n", ncol=2, cex=0.5),
         beside = TRUE,
)
 

legend("topright",  c("NP","OP", "NFP",  "Flat","NFP-R", "Flat-R"),  bty="n", ncol=2, cex=0.9, fill = plot_colors);
axis(2, las=1, at=c(0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000), labels=c("0K", "1K", "2K", "3K", "4K", "5K", "6K", "7K", "8K"), cex=0.1) 
mtext(2,text="Execution Time [min]",line=2.4) 
mtext(1,text="Execution Strategies",line=0.5) 

text(x=0.7, y=8300, labels="[1x]", cex=0.7)
text(x=1.9, y=2800, labels="[3.3x]", cex=0.7 )
text(x=3.1, y=990, labels="[14x]", cex=0.7 )
text(x=4.3, y=800, labels="[21x]", cex=0.7 )
text(x=5.5, y=650, labels="[29x]", cex=0.7 )
text(x=6.7, y=450, labels="[189x]", cex=0.7 )



box()	              # box around plot       
dev.off() 
