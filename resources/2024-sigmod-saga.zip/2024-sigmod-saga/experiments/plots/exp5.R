require(graphics)
require(Matrix)

pdf(file="exp5.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)

points = as.vector(seq(1,7));
inputNested = as.matrix(read.table("../result/exp5a.dat", sep="\t")[2])

# data = rowMeans(matrix(input,7,2))/1000000
data1 = inputNested/1000000
data1
ideal1 = data1[1] * points

inputFlat = as.matrix(read.table("../result/exp5b.dat", sep="\t")[2])
inputFlat
data2 = t(colMeans(matrix(inputFlat, 2, 7))/1000000)
data2
ideal2 = data2[1] * points
ideal2


plot_colors <- c("orange", "orangered", "black")

plot(   points, data1,     
        type="o",           
        pch=24, 
        cex=1.1,
        col=plot_colors[1],              
        ylim = c(0,53),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        log="",
	      lwd=1.1, 
	      lty=1
  )


axis(2, las=2, at = c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50), labels = paste0(c(0, 5, 10, 15, 20, 25, 30, 35, 40, 45, 50), "K"), cex.axis=0.7)# horizontal y axis
axis(1, las=1)      # horizontal x axis
mtext(2, text="Execution Time [s]",line=2.5) 
mtext(1, text="Row Replication Factor (x 14980)",line=2) 


lines(points, data2, type="o", pch=18, lty=1, lwd=1.1, col=plot_colors[2], cex=1.1)

lines(points, ideal1, type="l", lty=2, lwd=1.1, col=plot_colors[1], cex=1.0)
lines(points, ideal2, type="l", lty=2, lwd=1.1, col=plot_colors[2], cex=1.0)

#segments(16,0,16,570, lty=2, lwd=1.1)
text(9,900,"scale-up")

box()	

legend( "topleft",
       c("Nested Parfor", "Flatten Parfor", "Ideal Scaling"), col=plot_colors, pt.bg=plot_colors,
       pch=c(24, 18, NA), lty=c(1,1, 2), lwd=c(1.1), bty="n", cex=0.7);

dev.off() 
