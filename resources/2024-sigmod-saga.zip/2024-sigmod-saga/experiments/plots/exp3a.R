require(graphics)
require(Matrix)

pdf(file="exp3a.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)


plot_colors <- c("orangered", "black", "cornflowerblue", "blue")

data =  as.matrix(read.table("../result/exp3/allAcc.dat", sep="\t", header = TRUE))
points = data[,1]
data = data/100
print(data)


plot(points, data[,2],     
        type="o",           
        pch=13, 
        cex=1.1,
        col=plot_colors[1],              
        ylim = c(0.61, 0.82),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        lwd=1.1, 
        lty=1 )


axis(2, las=1, at=c(0.61,0.64, 0.67, 0.70, 0.73, 0.76, 0.79, 0.82), labels=c(0.61,0.64, 0.67, 0.70, 0.73, 0.76, 0.79, 0.82), cex.axis=1) # horizontal y axis
# axis(2, las=1, at=c(0.62, 0.65, 0.68, 0.71, 0.74, 0.77, 0.80, 0.83), labels=c(0.6, 0.62, 0.64, 0.66, 0.68, 0.7, 0.72, 0.74, 0.76, 0.78, 0.8, 0.82), cex.axis=0.75) # horizontal y axis
axis(1, las=1, at=points, cex.axis=1, line=0)      # horizontal x axis 
mtext(2, text="Accuracy", line=2.7) 
mtext(1, text="# iterations", line=2) 


lines(points, data[,3], type="o", pch=15, lty=1, lwd=1.1, col=plot_colors[2], bg=plot_colors[2], cex=1.0)
lines(points, data[,4], type="o", pch=17, lty=1, lwd=1.1, col=plot_colors[3], bg=plot_colors[3], cex=1.0)
lines(points, data[,5], type="o", pch=19, lty=1, lwd=1.1, col=plot_colors[4], bg=plot_colors[4], cex=1.0)
# lines(points, data[,6], type="o", pch=25, lty=1, lwd=1.1, col=plot_colors[5], bg=plot_colors[5], cex=1.0)
# lines(points, data[,7], type="o", pch=4, lty=1, lwd=1.1, col=plot_colors[6], bg=plot_colors[6], cex=1.0)
# lines(points, data[,8], type="o", pch=8, lty=1, lwd=1.1, col=plot_colors[7], bg=plot_colors[7], cex=1.0)

box()	

legend(7,0.76,
       c("EEG", "Titanic", "Movie", "Housing"), col=plot_colors[c(1,2,3,4)], 
       pch=c(13,15,17,19), lty=c(1), lwd=c(1.1), bty="n", ncol=2, cex=0.85, pt.bg=plot_colors[c(1,2,3,4)]);



dev.off() 
