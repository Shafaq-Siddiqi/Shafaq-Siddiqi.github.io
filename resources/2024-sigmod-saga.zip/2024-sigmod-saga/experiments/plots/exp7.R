require(graphics)
require(Matrix)

pdf(file="exp7.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)


plot_colors <- c("orangered", "black", "cornflowerblue", "blue")

data =  as.matrix(read.table("../result/exp7a.dat", sep="\t", header = TRUE))
pipTime =  as.matrix(read.table("../result/exp7a2.dat", sep="\t", header = TRUE))
points = data[,1]
data = t(data[, 2:ncol(data)])
pipTime = t(pipTime[, 2:ncol(pipTime)])
data
pipTime
plot_colors <- c("blue","cornflowerblue", "black", "orange", "orangeRed")
barplot(data,
        space = c(0, 0.5),
        xlab = "", 
        ylab = "",
        col=plot_colors,
        ylim = c(0,18000),
        axes = FALSE, 
        args.legend = list(x="topleft", bty="n", ncol=2, cex=0.7, x.intersp=0.5),
        legend.text = c("Pipeline 1", "Pipeline 2", "Pipeline 3", "Pipeline 4", "Pipeline 5"),
        beside = TRUE,
        names.arg = c("37 GB", "74 GB", "110 GB", "147 GB"),
        cex.names=0.9,
        line=-0.5, 

        )
        
barplot(pipTime,
        space = c(0, 0.5),
        xlab = "", 
        ylab = "",
        ylim = c(0,6000),
        axes = FALSE, 
        beside = TRUE, 
        xaxt="n",
        col=rgb(0, 1, 0, .5, alpha=0.05), add=TRUE)
        
axis(2, las=1, at=c(0, 2*10^3, 4*10^3, 6*10^3, 8*10^3, 10^4, 12*10^3, 14*10^3, 16*10^3, 18*10^3), labels=c("0", "2K", "4K", "6K", "8K", "10K", "12K", "14K", "16K", "18K"), cex.axis=0.8) # horizontal y axis
mtext(2,text="Execution Time [s]",line=2.5)
mtext(1,text="Data Cleaning Pipelines",line=1.8)
box()	

dev.off() 
