require(graphics)
require(Matrix)

pdf(file="empty.pdf",
  width=4.5, height=4.0, family="serif", pointsize=14)

data = matrix(1000, 2,3);
lab = data[,1]
data = t(as.matrix(data[2]))
data = data/1000

lab
plot_colors <- c("cornflowerblue","black", "gray40", "orange")

barplot( data, 
         space = c(0.2,0.2),
         xlab = "", 
         ylab = "",
         col=plot_colors,
         ylim = c(0,200),
         width=c(10,10,10, 10),
         axes = FALSE, 
         args.legend = list(x="topright", c("A","B", "C"), bty="n", ncol=1, cex=0.5),
         beside = TRUE,

)
 

legend("topright",  c("A","B", "C"),  bty="n", ncol=1, cex=0.75, fill = plot_colors);
axis(2, las=1, at=c(0,50,100,150,200), labels=paste0(c(0,50,100,150,200),"K"), cex=0.1) 
mtext(2,text="Execution Time [s]",line=2.9) 
mtext(1,text="Place holder",line=1) 



box()	              # box around plot       
dev.off() 
