#!/bin/bash -i

Rscript exp3a.R 
sing_tex pdfcrop exp3a.pdf exp3a.pdf


Rscript exp3b.R 
sing_tex pdfcrop exp3b.pdf exp3b.pdf


Rscript exp4a.R 
sing_tex pdfcrop exp4a.pdf exp4a.pdf

Rscript exp4b.R 
sing_tex pdfcrop exp4b.pdf exp4b.pdf


Rscript exp5a.R 
sing_tex pdfcrop exp5a.pdf exp5a.pdf

Rscript exp5b.R 
sing_tex pdfcrop exp5b.pdf exp5b.pdf

Rscript exp6a.R 
sing_tex pdfcrop exp6a.pdf exp6a.pdf

Rscript exp6b.R 
sing_tex pdfcrop exp6b.pdf exp6b.pdf