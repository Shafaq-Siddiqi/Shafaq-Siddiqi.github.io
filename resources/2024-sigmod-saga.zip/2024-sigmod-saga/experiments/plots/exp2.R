library(Matrix)
pdf(file="exp2.pdf",
    width=5, height=4.0, family="serif", pointsize=14)

folder = "../result/exp2.dat";


data = as.matrix(read.table(folder, header=FALSE, sep="\t"))
print(data)


points = data[, 1];
bc = data[, 2] * 100
ho = data[, 3] * 100
ho
points
plot_colors <- c("orange","cornflowerblue")



plot(   points, bc,     
        type="o",           
        pch=25, 
        cex=1.1,
        ylim = c(0,90),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        lwd=1.1, 
        lty=1
)


axis(2, las=1) # horizontal y axis
axis(1, las=1, at=data[, 1], cex.axis=0.8)      # horizontal x axis


mtext(2, text="Accuracy",line=2.8) 
mtext(1, text="# of records",line=2) 


lines(points, ho, type="o", pch=15, lty=1, lwd=1.1, col=plot_colors[2], bg=plot_colors[2], cex=1.0)


legend( "bottomright",
        c("BoostClean","Hands-off"), col=plot_colors, cex=1.0,
        pch=c(25,17), lty=c(1), lwd=c(1.1), bty="n", ncol=1, seg.len=1)

box()	
dev.off() 

