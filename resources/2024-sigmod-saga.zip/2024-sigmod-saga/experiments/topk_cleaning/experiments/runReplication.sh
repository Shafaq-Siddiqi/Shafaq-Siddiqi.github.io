#alpha
exp_num="V1"
task=evalClassification
sep=","
dataset=EEG
input=scalablityExp/$dataset/$dataset
for i in 0
do
  pathout=../archive/$exp_num/scalablity/$dataset/$i/
  mkdir -p $pathout
  start=$(date +%s%N)
  time -p runjava singlenode -f V1/topkTest1.dml -nvargs sep=$sep dirtyData=${input}${i}.csv  metaData=meta/meta_$dataset.csv\
  primitives=properties/primitives.csv parameters=properties/param.csv sample=1 topk=3 expectedIncrease=10 max_iter=10 rv=50 testCV=TRUE cvk=3 split=0.7 func=$task output=${pathout}/ 2>&1  | tee ${pathout}/screen.txt  
	end=$(date +%s%N)
	echo -e $i '\t' $((($end-$start)/1000000)) >> ../result/${dataset}_time.dat 
done | tee ${pathout}all.txt
