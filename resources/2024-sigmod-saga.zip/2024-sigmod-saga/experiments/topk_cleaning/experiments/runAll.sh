#echo
./runClassification.sh
./runRegression.sh