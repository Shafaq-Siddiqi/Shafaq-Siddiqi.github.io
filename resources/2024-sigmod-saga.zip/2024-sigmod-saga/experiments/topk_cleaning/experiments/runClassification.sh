#echo
exp_num="V1"
task=evalClassification
sep=","
for test in  movie EEG movie wineQualityRed puma babyProduct  
do
  pathout=../archive/$exp_num/$test/$i/
  mkdir -p $pathout
  runjava -f V1/topkTest1.dml -stats -nvargs sep=$sep dirtyData=data/$test/train.csv  metaData=meta/meta_$test.csv\
  primitives=properties/primitives.csv parameters=properties/param.csv sample=1 topk=3 expectedIncrease=5 max_iter=15 rv=50 testCV=TRUE cvk=3 split=0.7 func=$task output=${pathout}/ 2>&1  | tee ${pathout}/screen.txt  

  runjava -f V1/evaluatePip.dml -stats -args $sep data/$test/train.csv  data/$test/test.csv  meta/meta_$test.csv\
    ${pathout}/ FALSE $task ${pathout}/ 2>&1 | tee ${pathout}/screenEval.txt 
done
