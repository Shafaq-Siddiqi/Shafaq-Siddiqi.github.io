#!/usr/bin/env Rscript
args = commandArgs(trailingOnly=TRUE)
library(Matrix)

pdf(file=args[2],
    width=4.5, height=4.0, family="serif", pointsize=14)
getwd()
input = args[1];
name = args[3]
ystart = as.integer(args[4])
yend = as.integer(args[5])

acc = 0.72
acc
data = as.matrix(read.table(input, sep = ",",header = FALSE))
data = data[order(data[, 1], decreasing = FALSE),]
data
points = data[,1]
points
acc = data[1,2]
plot_colors <- c("orange","cornflowerblue","black")

plot(points, data[,2],     
        type="o",           
        pch=15, 
        cex=1.1,
        col=plot_colors[1],              
        ylim = c(ystart, yend),   
        xlab="",     
        ylab="",         
        axes=FALSE,    
        bg=plot_colors[1],
        lwd=1.1, 
        lty=1 )

axis(2, las=1) # horizontal y axis
axis(1, las=1, at=points, cex.axis=1)      # horizontal x axis
mtext(2, text="Accuracy",line=2.5) 
mtext(1, text=paste0("Percentage of ",name),line=2) 


lines(points, data[, 3], type="o", pch=17, lty=1, lwd=1.1, col=plot_colors[2])
abline(h=acc, col="black")
box()	
legend( "bottomright",
        c(name, "topK", "target"), col=plot_colors,
         pch=c(15, 17), lty=c(1), lwd=c(1.1), bty="n", cex=1);

dev.off() 

