#!/bin/bash -i

# scaling plots
# Rscript marPlot.R scale_marRes.csv scale_marRes.pdf "% of Scaling Errors" 55 75
# Rscript marPlot.R scale_mcarRes.csv scale_mcarRes.pdf "% of Scaling Errors" 55 75
# sing_tex pdfcrop scale_marRes.pdf scale_marRes.pdf 
# sing_tex pdfcrop scale_mcarRes.pdf scale_mcarRes.pdf 

# # # swapping plots
# Rscript marPlot.R swap_mcarRes.csv swap_mcarRes.pdf "% of Swap Errors" 55 75
# Rscript marPlot.R swap_marRes.csv swap_marRes.pdf "% of Swap Errors" 55 75
# sing_tex pdfcrop swap_mcarRes.pdf swap_mcarRes.pdf 
# sing_tex pdfcrop swap_marRes.pdf swap_marRes.pdf 

# # # Gaussian plots
# Rscript marPlot.R gn_marRes.csv gn_marRes.pdf "% of Gaussian Noise" 55 75
# Rscript marPlot.R gn_mcarRes.csv gn_mcarRes.pdf "% of Gaussian Noise" 55 75
# sing_tex pdfcrop gn_marRes.pdf gn_marRes.pdf 
# sing_tex pdfcrop gn_mcarRes.pdf gn_mcarRes.pdf 

# # # FD violations
# Rscript marPlot.R vfdRes.csv vfdRes.pdf "% of FD Violations" 55 75
# sing_tex pdfcrop vfdRes.pdf vfdRes.pdf 

# # # Missing values plots
# Rscript marPlot.R mcarRes2.csv mcarRes2.pdf "% of MCAR" 45 82
# Rscript marPlot.R marRes2.csv marRes2.pdf "% of MCAR" 45 82


# sing_tex pdfcrop mcarRes2.pdf mcarRes2.pdf 
# sing_tex pdfcrop marRes2.pdf marRes2.pdf 


# Rscript marPlot.R allErrors.csv allErrors.pdf "% of Errors" 55 75
# sing_tex pdfcrop allErrors.pdf allErrors.pdf 