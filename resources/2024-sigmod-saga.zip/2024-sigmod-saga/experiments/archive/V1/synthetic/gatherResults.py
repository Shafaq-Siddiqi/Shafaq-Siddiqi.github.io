import os
import sys
input = sys.argv[1]
output = sys.argv[2]
if os.path.exists(output):
    os.remove(output)
print(input)
print(output)

def scan_folder(parent):
    # iterate over all the files in directory 'parent'
    val = 0
    for file_name in os.listdir(parent):
        if file_name.endswith("bestAcc.csv"):
            print("inside if parent")
            print(parent)
            # if it's a txt file, print its name (or do whatever you want)
            # print(file_name)
            dir = parent.rsplit("/")[-1]
            print("dir "+dir)
            fn = "".join((parent, "/", file_name))
            fn2 = "".join((parent, "/", "dirtyScore.csv"))
            print(fn2)
            with open(fn, "r") as file:
                cleanAcc = file.readline()
                print("cleanAcc")
                print(cleanAcc)
                file.close()
            with open(fn2, "r") as file:
                dirtyAcc = file.readline()
                print("dirtyAcc")
                print(dirtyAcc)
                val = "".join([str(dir), str(","), str(dirtyAcc.strip()), str(","), str(cleanAcc.strip())])
                file.close()
            f = open(output, "a")
            f.write("%s\n" % val)
            f.close()
        else:
            current_path = "".join((parent, "/", file_name))
            print("else parent")
            print(parent)
            if os.path.isdir(current_path):
                # if we're checking a sub-directory, recursively call this method
                scan_folder(current_path)

if __name__ == '__main__':
    # acc = scan_folder("D:\\PhD TU Graz\\Pipelines\\experiments\\archive\\topkSyn\\diabetesSmall\\mnar")
    scan_folder(input)
    # scan_folder("D:\\PhD TU Graz\\Pipelines\\experiments\\archive\\topkSyn\\diabetesSmall\\mnar")
    # print("printing accuracy")
    # print(len(acc))