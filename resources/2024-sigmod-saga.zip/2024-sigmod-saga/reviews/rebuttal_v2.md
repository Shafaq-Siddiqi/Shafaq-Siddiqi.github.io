We appreciate the detailed and thoughtful comments by all reviewers and are convinced we can address the remaining concerns with tailored clarifications and additional details by converting our paper to a full-length (12+1)-page paper, as well as additional baseline comparisons with Learn2Clean.

--- REVIEWER 2
R2-O1: The paper was previously rejected from PVLDB research, mid October (with good but borderline reviews, and a recommendation to move it to the scalable data science track). Accordingly, we spent quite some time condensing the paper from 12 to 8 pages (due to an inconsistency of the SIGMOD website stating both 8 and 12 page limits), but we think this process further improved the paper (besides the improved experiments). When we were contacted by the PC chairs with an extended deadline of a few days for submitting a version up to 12 pages, we decided to stick to the 8 page version. During a revision, we will use this space to add more details clarifying the unclear aspects.

R2-O1-D1: We agree, preventing overfitting is important. The loss function in SAGA is a user-provided function (via function parameter) computing a domain-specific score such as accuracy. In our experiments we split the data into train, validation, and test splits, where the test split is never touched by the top-k pipeline enumeration (test accuracy in the experiments). The validation split is used for evaluating the different pipelines and hyper-parameters (train accuracy in the experiments). Both train, validation, and test splits are assumed to follow the same distribution of errors. In a revision, we would clarify the unclear aspects, add a summary table of these error distributions for the different datasets, and add more baseline models (including tree-based models that are indeed more robust to noise and missing values).

R2-O2: Thank you for pointing us to the related work. We will add this baseline to our experiments and related work.

R2-O3-D2: We will substantially extend the paper, including all necessary background (Hyperband, monotonicity, task-parallel parfor loops, and our genetic algorithm) in order to make it self-contained. Table 1 had already a column to indicate which primitives are applicable to pruning by monotonicity but we will describe that in more detail.

--- REVIEWER 3
R3-O1: Our major motivation for the simple yet robust genetic algorithm was simplicity and extensibility by new primitives. SAGA performs, however, internal checks to avoid adding the same operations consecutively. These checks are performed in the construction of logical pipelines where we have defined abstract classes for primitives and use them to avoid redundant pipelines. However, error-aware and primitive-aware construction of cleaning pipelines is interesting future work, and we'll add a discussion of the relationships to feature selection, including recent related work on "Wrapper Methods for Multi-Objective Feature Selection" at EDBT 2023. Furthermore, we will add an ablation study that systematically disables internal features to avoid redundancy in order to quantify their runtime impact.

R3-O2: Yes, small data and the complexity of the pipeline could cause overfitting. We apply cross-validation in a careful manner by dividing the data into folds before applying the pipeline separately, which affects summary statistics of cleaning primitives and makes it harder to overfit. Most importantly, we focus on top-K cleaning pipeline enumeration to allow users to select and potentially modify robust pipelines. Similar to the pruning of decision trees after training, there is also some room to select such robust pipelines semi-automatically in the future.


--- REVIEWER 4:
R4-O1: We really appreciate the new perspective on the topic and will add this aspect into the revised version of the paper. Specifically, we will discuss the pros and cons of training cleaning pipelines specific for given downstream ML applications versus more general, task-agnostic data cleaning.

R4-O2: Thanks again for the thorough feedback - we will improve the overview figure with such details and potentially add a skeleton of the overall enumeration algorithm (which includes Algorithm 1 for logical pipeline enumeration).

R4-D1: In the context of data cleaning for ML, the ML application refers to the user-provided, down-stream ML application (e.g., classification, regression, clustering) which provide a valuable signal of effective cleaning strategies, rendering the problem easier than data cleaning for arbitrary applications.

